#include "stdafx.h"
#include "Mail.h"
#include "MailDlg.h"
#include "MailConfigurationDlg.h"
#include "Smtp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMailDlg::CMailDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMailDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMailDlg)
	m_sBCC = _T("");
	m_sBody = _T("");
	m_sCC = _T("");
	m_sFile = _T("");
	m_sSubject = _T("");
	m_sTo = _T("");
	m_bDirectly = FALSE;
	//}}AFX_DATA_INIT

  //Load in the values from the registry
  CWinApp* pApp = AfxGetApp();
  CString sSection(_T("Settings"));
	m_nPort = pApp->GetProfileInt(sSection, _T("Port"), 25);
	m_sAddress = pApp->GetProfileString(sSection, _T("Address"));
	m_sHost = pApp->GetProfileString(sSection, _T("Host"));
	m_sName = pApp->GetProfileString(sSection, _T("Name"));
  m_Authenticate = (CSMTPConnection::LoginMethod) pApp->GetProfileInt(sSection, _T("Authenticate"), CSMTPConnection::NoLoginMethod);
  m_sUsername = pApp->GetProfileString(sSection, _T("Username"));
	m_sPassword = pApp->GetProfileString(sSection, _T("Password"));
  m_bAutoDial = (BOOL) pApp->GetProfileInt(sSection, _T("Autodial"), FALSE);
  m_sBoundIP = pApp->GetProfileString(sSection, _T("BoundIP"));
  m_sEncodingFriendly = pApp->GetProfileString(sSection, _T("EncodingFriendly"), _T("Western European (ISO)"));
  m_sEncodingCharset = pApp->GetProfileString(sSection, _T("EncodingCharset"), _T("iso-8859-1"));
  m_bMime = (BOOL) pApp->GetProfileInt(sSection, _T("Mime"), FALSE);
  m_bHTML = (BOOL) pApp->GetProfileInt(sSection, _T("HTML"), FALSE);

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMailDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMailDlg)
	DDX_Text(pDX, IDC_BCC, m_sBCC);
	DDX_Text(pDX, IDC_BODY, m_sBody);
	DDX_Text(pDX, IDC_CC, m_sCC);
	DDX_Text(pDX, IDC_FILE, m_sFile);
	DDX_Text(pDX, IDC_SUBJECT, m_sSubject);
	DDX_Text(pDX, IDC_TO, m_sTo);
	DDX_Check(pDX, IDC_DIRECTLY, m_bDirectly);
	//}}AFX_DATA_MAP

  if (pDX->m_bSaveAndValidate)
  {
    if (m_sTo.IsEmpty())
    {
      AfxMessageBox(_T("To: address is empty !"));
      pDX->PrepareEditCtrl(IDC_TO);
      pDX->Fail();
    }
  }
}

BEGIN_MESSAGE_MAP(CMailDlg, CDialog)
	//{{AFX_MSG_MAP(CMailDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONFIGURATION, OnConfiguration)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_BROWSE_FILE, OnBrowseFile)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_SEND_FROM_DISK, OnSendFromDisk)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CMailDlg::OnInitDialog()
{
  //Let the parent class do its thing
	CDialog::OnInitDialog();

  // Set big icon
	SetIcon(m_hIcon, TRUE);			
	
	return TRUE;
}

void CMailDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMailDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMailDlg::OnConfiguration() 
{
  CMailConfigurationDlg dlg;
	dlg.m_sAddress          = m_sAddress;
	dlg.m_sHost             = m_sHost;
	dlg.m_sName             = m_sName;
	dlg.m_nPort             = m_nPort;
  dlg.m_Authenticate      = m_Authenticate;
  dlg.m_sUsername         = m_sUsername;
  dlg.m_sPassword         = m_sPassword;
  dlg.m_bAutoDial         = m_bAutoDial;
  dlg.m_sBoundIP          = m_sBoundIP;
  dlg.m_sEncodingCharset  = m_sEncodingCharset;
  dlg.m_sEncodingFriendly = m_sEncodingFriendly;
  dlg.m_bMime             = m_bMime;
  dlg.m_bHTML             = m_bHTML;
  if (dlg.DoModal() == IDOK)
  {
	  m_sAddress          = dlg.m_sAddress;
	  m_sHost             = dlg.m_sHost;
	  m_sName             = dlg.m_sName;
	  m_nPort             = dlg.m_nPort;
    m_Authenticate      = (CSMTPConnection::LoginMethod) dlg.m_Authenticate;
    m_sUsername         = dlg.m_sUsername;
    m_sPassword         = dlg.m_sPassword;
    m_bAutoDial         = dlg.m_bAutoDial;
    m_sBoundIP          = dlg.m_sBoundIP;
    m_sEncodingCharset  = dlg.m_sEncodingCharset;
    m_sEncodingFriendly = dlg.m_sEncodingFriendly;
    m_bMime             = dlg.m_bMime;
    m_bHTML             = dlg.m_bHTML;
  }
}

CSMTPMessage* CMailDlg::CreateMessage()
{
	//Create the message
	CSMTPMessage* pMessage = new CSMTPMessage;
	CSMTPBodyPart attachment;

  //Set the mime flag
  pMessage->SetMime(m_bMime);

  //Set the charset of the message and all attachments
  pMessage->SetCharset(m_sEncodingCharset);
  attachment.SetCharset(m_sEncodingCharset);

  //Setup the all the recipient types for this message
	pMessage->AddMultipleRecipients(m_sTo, CSMTPMessage::TO);
	if (!m_sCC.IsEmpty()) 
		pMessage->AddMultipleRecipients(m_sCC, CSMTPMessage::CC);
	if (!m_sBCC.IsEmpty()) 
		pMessage->AddMultipleRecipients(m_sBCC, CSMTPMessage::BCC);
	if (!m_sSubject.IsEmpty()) 
		pMessage->m_sSubject = m_sSubject;
	if (!m_sBody.IsEmpty())
  {
    if (m_bHTML)
      pMessage->AddHTMLBody(m_sBody, _T(""));
    else
			pMessage->AddTextBody(m_sBody);
  }

  //Add the attachment(s) if necessary
	if (!m_sFile.IsEmpty()) 
		pMessage->AddMultipleAttachments(m_sFile);		

  //Setup the from address
	if (m_sName.IsEmpty()) 
  {
		pMessage->m_From = m_sAddress;
		pMessage->m_ReplyTo = m_sAddress;
	}
	else 
  {
    CSMTPAddress address(m_sName, m_sAddress);
		pMessage->m_From = address;
		pMessage->m_ReplyTo = address;
	}

  //Add one custom header (for test purpose)
  #ifdef _DEBUG
  pMessage->AddCustomHeader(_T("X-Program: CSTMPMessageTester"));
  #endif

  return pMessage;
}
	

void CMailDlg::OnSend() 
{
	if (UpdateData(TRUE))
  {
	  CWaitCursor wc;
	  if (m_sHost.IsEmpty()) 
		  OnConfiguration();
	  else 
    {
		  //Create the message
		  CSMTPMessage* pMessage = CreateMessage();

      //Uncomment the following lines to test the BodyPart methods and MHTML support,
      //Please bear in mind that you will have to change the paths to suit your system
      /*
      for (int i=0; i<message.GetNumberOfBodyParts(); i++)
        pMessage->RemoveBodyPart(i);

      //Setup all the body parts we want
      CSMTPBodyPart related;
      related.SetContentType(_T("multipart/related"));

      CSMTPBodyPart multialternative;
      multialternative.SetContentType(_T("multipart/alternative"));

      CSMTPBodyPart html;
      html.SetText(_T("<p><b>Here's My Mug Shot</b></p><IMG SRC=\"cid:PJ\" ALT=\"Mug Shot\">"));
      html.SetContentType(_T("text/html"));

      CSMTPBodyPart text;
      text.SetText(_T("If you see this then your email client is not mime / MHTML compliant"));

      CSMTPBodyPart gifFile;
      gifFile.SetFilename(_T("c:\\inetpub\\wwwroot\\images\\pj.gif"));
      gifFile.SetContentID(_T("PJ"));
      gifFile.SetContentType(_T("image/gif"));

      CSMTPBodyPart attach1;
      attach1.SetFilename(_T("C:\\config.sys"));

      //Add all the body parts to the message in the correct hierarchy
      multialternative.AddChildBodyPart(html);
      multialternative.AddChildBodyPart(text);
      related.AddChildBodyPart(multialternative);
      related.AddChildBodyPart(gifFile);
      pMessage->AddBodyPart(related);
      pMessage->GetBodyPart(0)->SetContentLocation(_T("http://localhost"));
      pMessage->AddBodyPart(attach1);
      */

		  //connect to server
		  CSMTPConnection connection;
      if (m_bAutoDial)
        connection.ConnectToInternet();
      BOOL bConnect = connection.Connect(m_sHost, m_Authenticate, m_sUsername, m_sPassword, m_nPort, m_sBoundIP);
		  if (!bConnect) 
      {
        CString sMsg;
			  sMsg.Format(_T("Couldn't connect to server!, Error:%d"), GetLastError());
			  AfxMessageBox(sMsg, MB_ICONSTOP);
		  }
		  else 
      {
        //Send the message
			  if (!connection.SendMessage(*pMessage)) 
        {
          CString sMsg;
				  sMsg.Format(_T("Couldn't send message!\nResponse:%s"), connection.GetLastCommandResponse());
				  AfxMessageBox(sMsg, MB_ICONSTOP);
			  }
		  }
      if (m_bAutoDial)
        connection.CloseInternetConnection();

      //Tidy up the heap memory
      delete pMessage;
	  }
  }
}

void CMailDlg::OnBrowseFile() 
{
  CDataExchange DX(this, TRUE);
  DDX_Text(&DX, IDC_FILE, m_sFile);
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("All Files (*.*)|*.*||"));
	if (dlg.DoModal() == IDOK) 
  {
		CString sNewFile = dlg.GetPathName();
    if (m_sFile.GetLength())
    {
      m_sFile += _T(", ");
      m_sFile += sNewFile;
    }
    else
      m_sFile = sNewFile;

    //Update the UI  
    CDataExchange DX2(this, FALSE);
    DDX_Text(&DX2, IDC_FILE, m_sFile);
  }
}

void CMailDlg::OnDestroy() 
{
  //Let the parent class do its thing
	CDialog::OnDestroy();
	
  //Save in the values from the registry
  CWinApp* pApp = AfxGetApp();
  CString sSection(_T("Settings"));
	pApp->WriteProfileInt(sSection, _T("Port"), m_nPort);
	pApp->WriteProfileString(sSection, _T("Address"), m_sAddress);
	pApp->WriteProfileString(sSection, _T("Host"), m_sHost);
	pApp->WriteProfileString(sSection, _T("Name"), m_sName);
  pApp->WriteProfileInt(sSection, _T("Authenticate"), m_Authenticate);
  pApp->WriteProfileString(sSection, _T("Username"), m_sUsername);
	pApp->WriteProfileString(sSection, _T("Password"), m_sPassword);
  pApp->WriteProfileInt(sSection, _T("Autodial"), m_bAutoDial);
  pApp->WriteProfileString(sSection, _T("BoundIP"), m_sBoundIP);
  pApp->WriteProfileString(sSection, _T("EncodingFriendly"), m_sEncodingFriendly);
  pApp->WriteProfileString(sSection, _T("EncodingCharset"), m_sEncodingCharset);
  pApp->WriteProfileInt(sSection, _T("Mime"), m_bMime);
  pApp->WriteProfileInt(sSection, _T("HTML"), m_bHTML);
}

void CMailDlg::OnSendFromDisk() 
{
	if (UpdateData(TRUE))
  {
    //Bring up a standard File Open dialog 
    CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Email Files (*.eml)|*.eml|All Files (*.*)|*.*||"), NULL);
    if (dlg.DoModal() == IDOK)
    {
		  //connect to server
		  CSMTPConnection connection;
      if (m_bAutoDial)
        connection.ConnectToInternet();
      BOOL bConnect = connection.Connect(m_sHost, m_Authenticate, m_sUsername, m_sPassword, m_nPort, m_sBoundIP);
		  if (!bConnect) 
      {
        CString sMsg;
			  sMsg.Format(_T("Couldn't connect to server!, Error:%d"), GetLastError());
			  AfxMessageBox(sMsg, MB_ICONSTOP);
		  }
		  else 
      {
        //Get the from field
        CSMTPAddress from(m_sName, m_sAddress);

        //Get the recipients (for testing purposes we only bother looking at m_sTo)
        CSMTPAddressArray* pRecipients = CSMTPMessage::ParseMultipleRecipients(m_sTo);

        //Send the message
        if (m_bDirectly)
        {
			    if (!connection.SendMessage(dlg.GetPathName(), *pRecipients, from)) 
          {
            CString sMsg;
				    sMsg.Format(_T("Couldn't send message!\nResponse:%s"), connection.GetLastCommandResponse());
				    AfxMessageBox(sMsg, MB_ICONSTOP);
			    }
        }
        else
        {
          CString sFile = dlg.GetPathName();
          CFile file;
          if (file.Open(sFile, CFile::modeRead | CFile::shareDenyWrite))
          {
            //Allocate some memory to read all the file from
            DWORD dwSize = file.GetLength();
            BYTE* pData = new BYTE[dwSize];

            try
            {
              //Read the message into memory
              file.Read(pData, dwSize);

              //and send it
              if (!connection.SendMessage(pData, dwSize, *pRecipients, from))
              {
                CString sMsg;
				        sMsg.Format(_T("Couldn't send message!\nResponse:%s"), connection.GetLastCommandResponse());
				        AfxMessageBox(sMsg, MB_ICONSTOP);
			        }
            }
            catch(CFileException* pEx)
            {
              pEx->Delete();
              AfxMessageBox(_T("Failed to read from the file to mail"));
            }

            //Tidy up the heap memory we have used
            delete [] pData;
          }
          else
            AfxMessageBox(_T("Failed to open the file"));
        }

        //Tidy up the heap memory
        delete pRecipients;
		  }
      if (m_bAutoDial)
        connection.CloseInternetConnection();
    }	
  }
}

void CMailDlg::OnSave() 
{
	if (UpdateData(TRUE))
  {
    //Bring up a standard File Save dialog 
    CFileDialog dlg(FALSE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Email Files (*.eml)|*.eml|All Files (*.*)|*.*||"), NULL);
    if (dlg.DoModal() == IDOK)
    {
      //And save it to disk
      CSMTPMessage* pMessage = CreateMessage();
      if (!pMessage->SaveToDisk(dlg.GetPathName()))
      {
        CString sMsg;
			  sMsg.Format(_T("Couldn't save to disk!, Error:%d"), GetLastError());
			  AfxMessageBox(sMsg, MB_ICONSTOP);
      }

      //Tidy up the heap memory
      delete pMessage;
    }	
  }
}
