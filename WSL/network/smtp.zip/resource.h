//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mail.rc
//
#define IDD_MAIL_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_CONFIGURATION               129
#define IDC_TO                          1000
#define IDC_CC                          1001
#define IDC_BCC                         1002
#define IDC_SUBJECT                     1003
#define IDC_BODY                        1004
#define IDC_FILE                        1005
#define IDC_BROWSE_FILE                 1006
#define IDC_SEND                        1007
#define IDC_CONFIGURATION               1008
#define IDC_NAME                        1009
#define IDC_ADDRESS                     1010
#define IDC_HOST                        1011
#define IDC_PORT                        1012
#define IDC_USERNAME                    1014
#define IDC_PASSWORD                    1015
#define IDC_PROMPT_USERNAME             1016
#define IDC_PROMPT_PASSWORD             1017
#define IDC_AUTHENTICATE                1018
#define IDC_AUTOCONNECT                 1019
#define IDC_IPS                         1020
#define IDC_ENCODING                    1021
#define IDC_MIME                        1022
#define IDC_HTML                        1023
#define IDC_SAVE                        1024
#define IDC_SEND_FROM_DISK              1025
#define IDC_DIRECTLY                    1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
