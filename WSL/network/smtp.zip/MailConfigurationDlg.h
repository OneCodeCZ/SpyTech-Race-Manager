class CMailConfigurationDlg : public CDialog
{
public:
	CMailConfigurationDlg(CWnd* pParent = NULL);   // standard constructor

	//{{AFX_DATA(CMailConfigurationDlg)
	enum { IDD = IDD_CONFIGURATION };
	CComboBox	m_ctrlEncoding;
	CComboBox	m_ctrlIPAddresses;
	CComboBox	m_ctrlAuthenticate;
	CStatic	m_ctrlPromptUsername;
	CStatic	m_ctrlPromptPassword;
	CEdit	m_ctrlUsername;
	CEdit	m_ctrlPassword;
	CString	m_sAddress;
	CString	m_sHost;
	CString	m_sName;
	int		m_nPort;
	CString	m_sPassword;
	CString	m_sUsername;
	BOOL	m_bAutoDial;
	CString	m_sBoundIP;
  CString m_sEncodingFriendly;
	BOOL	m_bMime;
	BOOL	m_bHTML;
	//}}AFX_DATA
  DWORD	m_Authenticate;
  CString m_sEncodingCharset;

protected:
	//{{AFX_VIRTUAL(CMailConfigurationDlg)
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

  int CBAddStringAndData(CWnd* pDlg, int nIDC, LPCTSTR pszString, DWORD dwItemData);
  BOOL AddLocalIpsToBindCombo();

	//{{AFX_MSG(CMailConfigurationDlg)
	afx_msg void OnSelchangeAuthenticate();
	afx_msg void OnHtml();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


void DDX_CBData(CDataExchange* pDX, int nIDC, DWORD& dwItemData);
