#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components

#include <afxtempl.h>
#include <afxsock.h>
#include <afxpriv.h>
#include <afxext.h>         // MFC extensions
