#include "stdafx.h"
#include "smtp.h"
#include "Mail.h"
#include "MailConfigurationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


struct _MC_charset
{
  TCHAR* pszFriendlyName;
  TCHAR* pszCharset;
};

_MC_charset g_charset[] =
{
  { _T("Arabic (Windows)"), _T("windows-1256") },
  { _T("Baltic (Windows)"), _T("windows-1257") },
  { _T("Central European (ISO)"), _T("iso-8859-2") },
  { _T("Central European (Windows)"), _T("windows-1250") },
  { _T("Chinese Simplified (GB2312)"), _T("gb2312") },
  { _T("Chinese Simplified (HZ)"), _T("hz-gb-2312") },
  { _T("Chinese Traditional (Big5)"), _T("big5") },
  { _T("Cyrilic (KOI8-R)"), _T("koi8-r") },
  { _T("Cyrillic (Windows)"), _T("windows-1251") },
  { _T("Greek (Windows)"), _T("windows-1253") },
  { _T("Hebrew (Windows)"), _T("windows-1255") },
  { _T("Japanese (JIS)"), _T("iso-2022-jp") },
  { _T("Korean"), _T("ks_c_5601") },
  { _T("Korean (EUC)"), _T("euc-kr") },
  { _T("Latin 9 (ISO)"), _T("iso-8859-15") },
  { _T("Thai (Windows)"), _T("windows-874") },
  { _T("Turkish (Windows)"), _T("windows-1254") },
  { _T("Unicode (UTF-7)"), _T("utf-7") },
  { _T("Unicode (UTF-8)"), _T("utf-8") },
  { _T("Vietnamese (Windows)"), _T("windows-1258") },
  { _T("Turkish (Windows)"), _T("windows-1254") },
  { _T("Western European (ISO)"), _T("iso-8859-1") },
  { _T("Western European (Windows)"), _T("windows-1252") },

};




CMailConfigurationDlg::CMailConfigurationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMailConfigurationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMailConfigurationDlg)
	m_sAddress = _T("");
	m_sHost = _T("");
	m_sName = _T("");
	m_nPort = 0;
	m_sPassword = _T("");
	m_sUsername = _T("");
	m_bAutoDial = FALSE;
	m_sBoundIP = _T("");
  m_sEncodingFriendly = _T("");
	m_bMime = FALSE;
	m_bHTML = FALSE;
	//}}AFX_DATA_INIT
  m_nPort = 25; //Use the default SMTP port
  m_Authenticate = CSMTPConnection::NoLoginMethod;
  m_sEncodingFriendly = _T("Western European (ISO)");
  m_sEncodingCharset = _T("iso-8859-1");
}

int CMailConfigurationDlg::CBAddStringAndData(CWnd* pDlg, int nIDC, LPCTSTR pszString, DWORD dwItemData)
{
  int nInserted = CB_ERR;
  CWnd* pComboBox = pDlg->GetDlgItem(nIDC);
  if (pComboBox)
  {
    nInserted = (int) pComboBox->SendMessage(CB_ADDSTRING, 0, (LPARAM) pszString);
    if (nInserted >= 0)
    {
      if (pComboBox->SendMessage(CB_SETITEMDATA, nInserted, dwItemData) == CB_ERR)
        nInserted = CB_ERR;
    }
  }
  return nInserted;
}

void CMailConfigurationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

  if (!pDX->m_bSaveAndValidate)
  {
    //Add the login methods to the combo box
    CBAddStringAndData(this, IDC_AUTHENTICATE, _T("None"), CSMTPConnection::NoLoginMethod);
    #ifndef CSMTP_NORSA
    CBAddStringAndData(this, IDC_AUTHENTICATE, _T("CRAM MD5"), CSMTPConnection::CramMD5Method);
    #endif
    CBAddStringAndData(this, IDC_AUTHENTICATE, _T("AUTH LOGIN"), CSMTPConnection::AuthLoginMethod);
    CBAddStringAndData(this, IDC_AUTHENTICATE, _T("LOGIN PLAIN"), CSMTPConnection::LoginPlainMethod);

    //Add the charset methods to the combo box
    for (int i=0; i<sizeof(g_charset)/sizeof(_MC_charset); i++)
      CBAddStringAndData(this, IDC_ENCODING, g_charset[i].pszFriendlyName, i);
  }

  //Add the IP address to the combo
  if (!pDX->m_bSaveAndValidate)
  {
    DDX_Control(pDX, IDC_IPS, m_ctrlIPAddresses);
    AddLocalIpsToBindCombo();

    if (m_sBoundIP == _T(""))
      m_sBoundIP = _T("ANY_IP_ADDRESS");
  }


	//{{AFX_DATA_MAP(CMailConfigurationDlg)
	DDX_Control(pDX, IDC_ENCODING, m_ctrlEncoding);
	DDX_Control(pDX, IDC_AUTHENTICATE, m_ctrlAuthenticate);
	DDX_Control(pDX, IDC_PROMPT_USERNAME, m_ctrlPromptUsername);
	DDX_Control(pDX, IDC_PROMPT_PASSWORD, m_ctrlPromptPassword);
	DDX_Control(pDX, IDC_USERNAME, m_ctrlUsername);
	DDX_Control(pDX, IDC_PASSWORD, m_ctrlPassword);
	DDX_Text(pDX, IDC_ADDRESS, m_sAddress);
	DDX_Text(pDX, IDC_HOST, m_sHost);
	DDX_Text(pDX, IDC_NAME, m_sName);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	DDV_MinMaxInt(pDX, m_nPort, 1, 32000);
	DDX_Text(pDX, IDC_PASSWORD, m_sPassword);
	DDX_Text(pDX, IDC_USERNAME, m_sUsername);
	DDX_Check(pDX, IDC_AUTOCONNECT, m_bAutoDial);
	DDX_CBString(pDX, IDC_IPS, m_sBoundIP);
  DDX_CBString(pDX, IDC_ENCODING, m_sEncodingFriendly);
	DDX_Check(pDX, IDC_MIME, m_bMime);
	DDX_Check(pDX, IDC_HTML, m_bHTML);
	//}}AFX_DATA_MAP
  DDX_CBData(pDX, IDC_AUTHENTICATE, m_Authenticate);

  if (pDX->m_bSaveAndValidate)
  {
    int nSel = m_ctrlEncoding.GetCurSel();
    if (nSel != -1)
      m_sEncodingCharset = g_charset[nSel].pszCharset;

    if (m_sAddress.IsEmpty())
    {
      AfxMessageBox(_T("Please specify a valid email address"));
      pDX->PrepareEditCtrl(IDC_ADDRESS);
      pDX->Fail();
    }
    if (m_sHost.IsEmpty())
    {
      AfxMessageBox(_T("Please specify a valid SMTP host"));
      pDX->PrepareEditCtrl(IDC_HOST);
      pDX->Fail();
    }

    if (m_Authenticate != 0)
    {
      if (m_sUsername.IsEmpty())
      {
        AfxMessageBox(_T("Please specify a valid username"));
        pDX->PrepareEditCtrl(IDC_USERNAME);
        pDX->Fail();
      }
    }
  }

  if (!pDX->m_bSaveAndValidate)
    OnSelchangeAuthenticate();
  else
  {
    if (m_sBoundIP == _T("ANY_IP_ADDRESS"))
      m_sBoundIP = _T("");
  }
}

BOOL CMailConfigurationDlg::AddLocalIpsToBindCombo()
{
  //Enumerate the IP's on this machine and add them to the drop down combo 
  //for for binding

  //get this machines host name
  char szHostname[256];
  if (gethostname(szHostname, sizeof(szHostname)))
  {
    TRACE(_T("Failed in call to gethostname, WSAGetLastError returns %d\n"), WSAGetLastError());
    return FALSE;
  }

  //get host information from the host name
  HOSTENT* pHostEnt = gethostbyname(szHostname);
  if (pHostEnt == NULL)
  {
    TRACE(_T("Failed in call to gethostbyname, WSAGetLastError returns %d\n"), WSAGetLastError());
    return FALSE;
  }

  //check the length of the IP adress
  if (pHostEnt->h_length != 4)
  {
    TRACE(_T("IP address returned is not 32 bits !!\n"));
    return FALSE;
  }

  //call the virtual callback function in a loop
  m_ctrlIPAddresses.ResetContent();
  m_ctrlIPAddresses.AddString(_T("ANY_IP_ADDRESS"));
  int nAdapter = 0;
  while (pHostEnt->h_addr_list[nAdapter])
  {
    in_addr address;
    CopyMemory(&address.S_un.S_addr, pHostEnt->h_addr_list[nAdapter], pHostEnt->h_length);
    //bContinue = EnumCallbackFunction(nAdapter, address);
    CString sIP;
    sIP.Format(_T("%d.%d.%d.%d"), address.S_un.S_un_b.s_b1, address.S_un.S_un_b.s_b2, address.S_un.S_un_b.s_b3, address.S_un.S_un_b.s_b4);
    m_ctrlIPAddresses.AddString(sIP);
    nAdapter++;
  }
  m_ctrlIPAddresses.SetCurSel(0);

  return TRUE;
}


BEGIN_MESSAGE_MAP(CMailConfigurationDlg, CDialog)
	//{{AFX_MSG_MAP(CMailConfigurationDlg)
	ON_CBN_SELCHANGE(IDC_AUTHENTICATE, OnSelchangeAuthenticate)
	ON_BN_CLICKED(IDC_HTML, OnHtml)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CMailConfigurationDlg::OnSelchangeAuthenticate() 
{
  BOOL bAuthenticated = (m_ctrlAuthenticate.GetCurSel() != 0);
  m_ctrlUsername.EnableWindow(bAuthenticated);
  m_ctrlPromptUsername.EnableWindow(bAuthenticated);
  m_ctrlPassword.EnableWindow(bAuthenticated);
  m_ctrlPromptPassword.EnableWindow(bAuthenticated);
}

void DDX_CBData(CDataExchange* pDX, int nIDC, DWORD& dwItemData)
{
  HWND hWndCtrl = pDX->PrepareCtrl(nIDC);
  if (pDX->m_bSaveAndValidate)
  {
    dwItemData = 0L;
    int nCurSel = (int) ::SendMessage(hWndCtrl, CB_GETCURSEL, 0, 0L);
    if (nCurSel != CB_ERR)
      dwItemData = ::SendMessage(hWndCtrl, CB_GETITEMDATA, nCurSel, 0L);
  }
  else
  {
    for (int nIndex = (int) ::SendMessage(hWndCtrl, CB_GETCOUNT, 0, 0L) - 1; 
      nIndex >= 0; nIndex--)
    {
      DWORD dwData = ::SendMessage(hWndCtrl, CB_GETITEMDATA, nIndex, 0L);
      if (dwData == dwItemData)
      {
        ::SendMessage(hWndCtrl, CB_SETCURSEL, nIndex, 0L);
        break;
      }
    }
    if (nIndex < 0) // item wasn't found
      SendMessage(hWndCtrl, WM_SETTEXT, 0, (LPARAM) (LPCSTR) "???");
  }
}

void CMailConfigurationDlg::OnHtml() 
{
  CDataExchange DX(this, TRUE);
  DDX_Check(&DX, IDC_HTML, m_bHTML);
  if (m_bHTML)
  {
    m_bMime = TRUE;
    CDataExchange DX2(this, FALSE);
    DDX_Check(&DX2, IDC_MIME, m_bMime);    
  }  	
}
