#include "smtp.h"

class CMailDlg : public CDialog
{
public:
	CMailDlg(CWnd* pParent = NULL);	// standard constructor

	//{{AFX_DATA(CMailDlg)
	enum { IDD = IDD_MAIL_DIALOG };
	CString	m_sBCC;
	CString	m_sBody;
	CString	m_sCC;
	CString	m_sFile;
	CString	m_sSubject;
	CString	m_sTo;
	BOOL	m_bDirectly;
	//}}AFX_DATA
	CString	m_sAddress;
	CString	m_sHost;
	CString	m_sName;
	int m_nPort;
  CSMTPConnection::LoginMethod m_Authenticate;
  CString m_sUsername;
	CString m_sPassword;
  BOOL    m_bAutoDial;
  CString m_sBoundIP;
  CString m_sEncodingFriendly;
  CString m_sEncodingCharset;
  BOOL    m_bMime;
  BOOL    m_bHTML;

	//{{AFX_VIRTUAL(CMailDlg)
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	HICON m_hIcon;

  CSMTPMessage* CreateMessage();

	//{{AFX_MSG(CMailDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnConfiguration();
	afx_msg void OnSend();
	afx_msg void OnBrowseFile();
	afx_msg void OnDestroy();
	afx_msg void OnSendFromDisk();
	afx_msg void OnSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

